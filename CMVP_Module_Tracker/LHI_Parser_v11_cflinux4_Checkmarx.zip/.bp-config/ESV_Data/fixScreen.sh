xrandr --newmode  "1920x979_60.00"  155.75  1920 2040 2240 2560  979 982 992 1016 -hsync +vsync
xrandr --addmode Virtual1 "1920x979_60.00"

xrandr -s "1920x979_60.00"

 