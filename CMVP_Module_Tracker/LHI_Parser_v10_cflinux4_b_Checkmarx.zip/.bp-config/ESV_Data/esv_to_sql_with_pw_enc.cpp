#include <stdio.h>
#include <//usr/include/postgresql/libpq-fe.h>  //ubuntu

#include <iostream>
#include <fstream>
#include <string>
#include "utils.h"
#include <unistd.h>
#include <sstream>
#include <stdarg.h>  //ubuntu
#include <time.h>
#include "../dev_or_prod.h"



//#include "Active_Indicator_sql.h"

//global variables
PGconn *conn;
char * MasterStr;


//PROTOTYPES



//==============================================================

#include <openssl/aes.h>

int rgf(){
// #include <openssl/aes.h>

AES_KEY aesKey_;
//unsigned char userKey_[]="0003141592653598";
//unsigned char userKey_[16];
unsigned char decryptedPW[16];

//unsigned char encryptedPW[16];



  
 //AES_ctr128_encrypt


srand (time(NULL));
int x=rand();
//int i;
for (int i=0;i<16;i++)
{	
userKey_[i]= 	rand();
}

//userKey_[0]= userKey_[0] - x;//	rand();


//	AES_set_encrypt_key(userKey_, 128, &aesKey_);
  //  AES_encrypt(encryptedPW, encryptedPW, &aesKey_);
 // AES_encrypt(encryptedPW, encryptedPW, &userKey_);


 //   AES_set_decrypt_key(userKey_, 128, &aesKey_);
  //  AES_decrypt(IntelencryptedPW, encryptedPW,&aesKey_);
  //  AES_decrypt(IntelencryptedPW, encryptedPW,&userKey_);

    fprintf(stdout,"\nPlainText: %s\n", encryptedPW);     
    fprintf(stdout,"\nPlainText: %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x \n", encryptedPW[0],encryptedPW[1],encryptedPW[2],encryptedPW[3],encryptedPW[4],encryptedPW[5],encryptedPW[6],encryptedPW[7],encryptedPW[8],encryptedPW[9],encryptedPW[10],encryptedPW[11],encryptedPW[12],encryptedPW[13],encryptedPW[14],encryptedPW[15]);     
     
    return 0;



 return 0;
    

} //rgf




//============================================================
int main (int argc, char* argv[]) {

	const char *Table_Name="CMVP_Active_Table";
	char *file_path;
	char *file_num;

	long int file_pos=0;
	
	//char sql1 [SQL_MAX];
	//PGresult *sql_result;
	data_t data;
	int i;
	int myX;

	

rgf();




	return(0);


} //main