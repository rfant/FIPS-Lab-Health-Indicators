

<?php
//this php file defines whether the URL is for production or development



//$URL_str="//127.0.0.1";  //development (my laptop is the server)

//$URL_str="https://fips-lab-indicator.apps1-fm-int.icloud.intel.com";
 $URL_str="fips-lab-indicator.apps1-fm-int.icloud.intel.com";
// $URL_str=".";

?>  
