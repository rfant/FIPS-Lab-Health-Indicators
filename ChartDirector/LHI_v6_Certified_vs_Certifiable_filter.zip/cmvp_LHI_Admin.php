
<?php
//require_once("phpchartdir.php");


echo "<br>Show Admins<br>"; //$show_admins = $c->addText($buttonX-100, $buttonY, "Show Admins","arialbd.ttf", 10); //draw button
//$show_admins->setSize(80, 30);
//$show_admins->setBackground(gray1,-1,2);
//$show_admins->setAlignment (5);
//$coor_show_admins = $show_admins->getImageCoor();


echo "<br> Add Admins<br>";//$add_admins = $c->addText($buttonX-100, $buttonY+50, "Add Admins","arialbd.ttf", 10); //draw button
//$add_admins->setSize(80, 30);
//$add_admins->setBackground(gray1,-1,2);
//$add_admins->setAlignment (5);
//$coor_add_admins = $add_admins->getImageCoor();

echo "<br> Delete Admins<br>";//$delete_admins = $c->addText($buttonX-100, $buttonY+100, "Delete Admins","arialbd.ttf", 10); //draw button
//$delete_admins->setSize(80, 30);
//$delete_admins->setBackground(gray1,-1,2);
//$delete_admins->setAlignment (5);
//$coor_delete_admins = $delete_admins->getImageCoor();


echo "<br> Add Intel Certifiable Product<br>"; //$add_certifiable = $c->addText($buttonX-100, $buttonY+100, "Add Certifiable","arialbd.ttf", 10); //draw button
//$add_certifiable->setSize(80, 30);
//$add_certifiable->setBackground(gray1,-1,2);
//$add_certifiable->setAlignment (5);
//$coor_add_certifiable = $add_certifiable->getImageCoor();

?>
