

<!--==================================================================================-->

<?php
require_once("../lib/phpchartdir.php");


//get the start and end date. 
 $self = isset($_SERVER['PHP_SELF']) ? $_SERVER['PHP_SELF'] : '#';
 $now = date("Y-m-d");
 
 $today1 = isset($_POST['today1']) ? $_POST['today1'] : '1995-01-01' ; //Ealiest CMVP validation date
 $today2 = isset($_POST['today2']) ? $_POST['today2'] : (new DateTime)->format('Y-m-d');
  
 $startDate = isset($_REQUEST["startDate"]) ? date('Y-m-d',strtotime($_REQUEST["startDate"])) : date('Y-m-d', strtotime($today2));
 $endDate = isset($_REQUEST["endDate"]) ? date('Y-m-d',strtotime($_REQUEST["endDate"])) : date('Y-m-d', strtotime($today2));

$startDateOut=$startDate;  //used to keep track of which button is selected at the top if "Today" is choosen since there is no other app with "Today" option
$endDateOut=$endDate;

 $in_TopButtons=isset($_REQUEST["in_TopButtons"]) ? $_REQUEST["in_TopButtons"] : 5;
 
 if($in_TopButtons < 0)
 {
  $in_TopButtonsOut=($in_TopButtons * -1);
 
   $in_TopButtons=5;
 }
 else
  $in_TopButtonsOut=$in_TopButtons;

 $zoom=isset($_REQUEST["zoom"]) ? $_REQUEST["zoom"] : 1;



 //if($in_TopButtons==5){
 // $startDate=date('Y-m-d', strtotime($today2));
 // $endDate=date('Y-m-d', strtotime($today2));
//}
//else 
//  $in_TopButtons=5;  //always default to "Today" when first coming into app.

 //echo "startDate=".$startDate.". endDate=".$endDate.". in_TopButtons=".$in_TopButtons.". <br></br>";
 //echo "endDate=".$endDate;



define        ("red",0x00FF0000);
define      ("green",0x0000FF00);
define       ("blue",0x000000FF);
define ("light_blue",0x00eeeeff);
define  ("blue_gray",0x0098AFC7);
define ("light_blue2",0x0099ccff);
define  ("deep_blue",0x000000cc);
define      ("white",0x00FFFFFF);
define      ("black",0x00000000);
define      ("gray1",0x00dcdcdc);
define     ("yellow",0x00FFFF00);
define ("yellow_green",0x0052D017);
define ("green_yellow",0x00B1FB17);
define ("gray_cloud",0x00B6B6B4);
define ("battleship_gray",0x00848482);
define ("pumpkin_orange",0x00F87217);
define ("platinum",0x00E5E4E2);
define ("light_slate_gray",0x006D7B8D);
define ("marble_blue",0x00566D7E);

define ("dark_slate_blue",0x002B3856);
define ("cobalt_blue",0x000020C2);


$data0 = array();   //Revoked
$data1 = array();   //Historic
$data2 = array();   //Active
$labels= array();	// Lab Names



//===============================================
#connect to postgreSQL database and get my chart data

$appName = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$connStr = "host=postgres.aus.atsec  dbname=fantDatabase user=richard password==uwXg9Jo'5Ua connect_timeout=5 options='--application_name=$appName'";


$conn = pg_connect($connStr);

//Here we ignore dates. Just see if the criteria of null and not_null filters out the non-Today data. So far, it's worked.
$sql_Str_Today = " 
select 'others' as type, 
(select count (*) as RP   from \"CMVP_MIP_Table\" where \"Review_Pending_Start_Date\" is not null AND \"In_Review_Start_Date\" is null 
AND \"Coordination_Start_Date\" is null and \"Finalization_Start_Date\" is null and (\"Status2\" like '%Reappear%'  OR \"Status2\" is NULL 
OR \"Status2\"  like 'DUP%' )) ,
(select count(*) as IR from \"CMVP_MIP_Table\" where \"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is null 
and \"Finalization_Start_Date\" is null
and (\"Status2\" like '%Reappear%'  OR \"Status2\" is NULL OR \"Status2\"  like 'DUP%') ),
(select count (*) as CO from \"CMVP_MIP_Table\" where \"Coordination_Start_Date\" is not null AND \"Finalization_Start_Date\" is null 
and (\"Status2\" like '%Reappear%'  OR \"Status2\" is NULL OR \"Status2\" like 'DUP%') )
 union
select 'atsec' as type, 
(select count(*)   from \"CMVP_atsec_Only_MIP_Table\" where   \"Review_Pending_Start_Date\" is not null AND \"In_Review_Start_Date\" is  
null AND \"Coordination_Start_Date\" is null and \"Finalization_Start_Date\" is null and (\"Status2\"  is null or \"Status\" like '%Promoted%' ) )as RP,
(select count(*)   from \"CMVP_atsec_Only_MIP_Table\" where   \"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is null 
and \"Finalization_Start_Date\" is null and (\"Status2\"  is null OR \"Status2\" like '%Promoted%') ) as IR,
(select count(*)   from \"CMVP_atsec_Only_MIP_Table\" where    \"Coordination_Start_Date\" is not null and \"Finalization_Start_Date\" 
is null and (\"Status2\"  is null OR \"Status2\" like '%Promoted%')) as CO order by type asc
";


$sql_Str_Historic="
select 'atsec' as type, 
(select count(*) from \"CMVP_atsec_Only_MIP_Table\" where \"Review_Pending_Start_Date\" is not null   and (\"Status2\" is null OR \"Status2\" like '%Promoted%') and \"Review_Pending_Start_Date\" between '".$startDate."' AND '".$endDate."' ) as RP, 

(select count(*) from \"CMVP_atsec_Only_MIP_Table\" where \"In_Review_Start_Date\" is not null  
  and (\"Status2\" is null OR \"Status2\" like '%Promoted%') and \"In_Review_Start_Date\" between '".$startDate."' AND '".$endDate."' ) as IR,

(select count(*) from \"CMVP_atsec_Only_MIP_Table\" where \"Coordination_Start_Date\" is not null and (\"Status2\" is null OR \"Status2\" like '%Promoted%') 
 and \"Coordination_Start_Date\" between '".$startDate."' AND '".$endDate."' ) as CO 

UNION
select 'others' as type, (
select count (*)  from \"CMVP_MIP_Table\" where \"Review_Pending_Start_Date\" is not null  and (\"Status2\" like '%Reappear%' OR \"Status2\" is NULL OR \"Status2\" like 'DUP%' )  and \"Review_Pending_Start_Date\" between '".$startDate."' AND '".$endDate."' ) as RP, 

(select count(*)  from \"CMVP_MIP_Table\" where \"In_Review_Start_Date\" is not null   and (\"Status2\" like '%Reappear%' OR \"Status2\" is NULL OR \"Status2\" like 'DUP%') 
and \"In_Review_Start_Date\" between '".$startDate."' AND '".$endDate."' ) as IR, 

(select count (*)  from \"CMVP_MIP_Table\" where \"Coordination_Start_Date\" is not null  and (\"Status2\" like '%Reappear%' OR \"Status2\" is NULL OR \"Status2\" like 'DUP%') 
and \"Coordination_Start_Date\" between '".$startDate."' AND '".$endDate."' ) as CO

order by type asc

";



if($in_TopButtons==5)
{
  //echo "Charlie SQL Today=".$sql_Str_Today;
  $result = pg_query($conn,$sql_Str_Today);
}
else
{  
 //echo "Charlie SQL Historic=".$sql_Str_Historic;
  $result= pg_query($conn,$sql_Str_Historic);
}

$arr = pg_fetch_all($result);
//print_r($arr);


if($arr==null)
	$num_mod=0;
else
	$num_mod=sizeof($arr);

if($num_mod>0)
{
	foreach($arr as $row){
		$labels[]=$row['type'];
	}

	foreach($arr as $row){
		$data0[]=$row['rp'];
	}
	foreach($arr as $row){
		$data1[]=$row['ir'];
	}
	foreach($arr as $row){
		$data2[]=$row['co'];
	}
} //num_mod > 0



//===================  configure and draw the chart ========================

# Create a XYChart object of size 800 x 600 pixels

//$zoom=1;
$width=$zoom*800;
$height=$zoom*600;



//$c = new XYChart($width,$height, brushedSilverColor(), Transparent, 2);
$c = new XYChart($width, $height, light_blue, black, 1);
$c->setRoundedFrame();


//-------------
# Add a title to the chart using 15pt Times Bold Italic font. The text is white (ffffff) on a blue
# (0000cc) background, with glass effect.
$title = $c->addTitle("CMVP MIP Indicator ", "timesbi.ttf", 15, 0xffffff);
$title->setBackground(0x0000cc, 0x000000, glassEffect(ReducedGlare));

# Set the plotarea at (80, 100) and of size w-200 x h-160 pixels. 
//start          x,   y, w,   h,   background color, alt background color,edge color, horiz grid color, vert grid color
$c->setPlotArea(80, 100, $width-200, $height-160, white, -1, Transparent, 0x000000);
$c->setRoundedFrame(0xffffff, 20);


//-----------------------------------------------
// draw a clickable text message for others regarding the SWAG

$non_atsec_msgX=180;
$non_atsec_msgY=150;
$non_atsec_msg1=$c->addText($non_atsec_msgX,$non_atsec_msgY,"(Best Guess Based on ","arialbd.tff",14);
$non_atsec_msg1->SetFontColor(red);
$non_atsec_msg1->setSize(150,30);
$non_atsec_msgX+=200;
$non_atsec_msg2=$c->addText($non_atsec_msgX,$non_atsec_msgY,"CMVP MIP Website)","arialbd.tff",14); 
$non_atsec_msg2->SetFontColor(red);
$non_atsec_msg2->setSize(150,30);
$coor_non_atsec_msg2=$non_atsec_msg2->getImageCoor();//attach CMVP hyperlink below  for the "CMVP MIP" text above


//-----------------------------------------------
//Draw some buttons

$buttonX=$width-100; //700;
$buttonY=$height - 500; //100;


$zoomIn = $c->addText($buttonX+10, $buttonY-60, "+","arialbd.ttf", 10); //draw button
$zoomIn->setSize(20, 20);
$zoomIn->setBackground(gray1,-1,2);
$zoomIn->setAlignment (5);
$coor_zoomIn = $zoomIn->getImageCoor();


$zoomOut = $c->addText($buttonX+40, $buttonY-60, "-","arialbd.ttf", 12); //draw button
$zoomOut->setBackground(gray1,-1,2);
$zoomOut->setSize(20, 20);
$zoomOut->setAlignment (5);
if($zoom <=1)
  $coor_zoomOut =0;
 else
  $coor_zoomOut = $zoomOut->getImageCoor(); //only make clickable button if zoom in already used.


$zoomClear = $c->addText($buttonX+70, $buttonY-60, "!","arialbd.ttf", 12); //draw button
$zoomClear->setSize(20, 20);
$zoomClear->setBackground(gray1,-1,2);
$zoomClear->setAlignment (5);
$coor_zoomClear = $zoomClear->getImageCoor();


//gray1 on
//battleship_gray off

$button1 = $c->addText($buttonX, $buttonY, "Status","arialbd.ttf", 10); //draw button
$button1->setSize(80, 30);
$button1->setBackground(gray1,-1,2);
$button1->setAlignment (5);
$coor_button1 = $button1->getImageCoor();

$button2 = $c->addText($buttonX, $buttonY+50, "Mod Type","arialbd.ttf", 10); //draw button
$button2->setSize(80, 30);
$button2->setBackground(gray1,-1,2);
$button2->setAlignment (5);
$coor_button2 = $button2->getImageCoor();


$button3 = $c->addText($buttonX, $buttonY+100, "MIP","arialbd.ttf", 10); //draw button
$button3->setSize(80, 30);
$button3->setBackground(battleship_gray,-1,-2);
$button3->setAlignment (5);
$coor_button3 = $button3->getImageCoor();


//------ Trend Label



$button4 = $c->addText($buttonX, $buttonY+150, "Trend","arialbd.ttf", 10); //draw button
$button4->setSize(80, 30);
$button4->setBackground(gray1,-1,2);
$button4->setAlignment (5);
$coor_button4 = $button4->getImageCoor();

$button5 = $c->addText($buttonX, $buttonY+200, "Forecast","arialbd.ttf", 10); //draw button
$button5->setSize(80, 30);
$button5->setBackground(gray1,-1,2);
$button5->setAlignment (5);
$coor_button5 = $button5->getImageCoor();


# Swap the x and y axes to create a horizontal bar chart
$c->swapXY();

# Add a legend box at (280, 50) using vertical layout and 12pt Arial font. Set background and border
# to transparent and key icon border to the same as the fill color.
//                   x,  y,  vertical?, font       , font size
$b = $c->addLegend(80, 50,      false, "arialbd.ttf", 12);
$b->setBackground(Transparent, Transparent);
$b->setKeyBorder(SameAsMainColor);



# Add a stacked bar layer chart
$layer = $c->addBarLayer2(Stack);


# Add the three data sets to the bar layer
$layer->addDataSet($data0, light_blue2, "Review Pending");
$layer->addDataSet($data1, red, "In Review");
$layer->addDataSet($data2, green, "Coordination");
//------------------------

$layer->setBarWidth(50 );

//----------------------
# Set the bar border to transparent
$layer->setBorderColor(Transparent, softLighting(Top));

# Enable labelling for the entire bar and use 12pt Arial font
$layer->setAggregateLabelStyle("arialbd.ttf", 12);

# Enable labelling for the bar segments and use 12pt Arial font with center alignment
$textBoxObj = $layer->setDataLabelStyle("arialbd.ttf", 10);
$textBoxObj->setAlignment(Center);

# Set x axis labels using the given labels
$c->xAxis->setLabels($labels);


# Add a title to the y axis with 12pt Times Bold Italic font
$c->yAxis->setTitle("Number of Modules", "timesbi.ttf", 12);

# Set axis label style to 8pt Arial Bold
$c->xAxis->setLabelStyle("arialbd.ttf", 8);
$c->yAxis->setLabelStyle("arialbd.ttf", 8);

# Set axis line width to 2 pixels
$c->xAxis->setWidth(2);
$c->yAxis->setWidth(2);

# Create the image and save it in a temporary location
$chart1URL = $c->makeSession("chart1");

# Create an image map for the chart

$imageMap = $c->getHTMLImageMap("CMVP_Show_Details_MIP_Pareto.php", "{default}&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate, "title='{xLabel}: {value|0} modules'");
  

?>


<!--//=======================================================-->

<body style="margin:5px 0px 0px 5px">
<!--<div style="font-size:18pt; font-family:verdana; font-weight:bold">
    CMVP MIP Indicator as of  <?php echo $endDate ?>
</div>-->


 <table> <!-- date buttons -->

  <form action="<?= $self; ?>" method="POST"> 
  
    <tr>    <td align="right"> Start Date <input type="date" name="startDate" value="<?= $startDate;?>">   
      <td rowspan="2"> <td colspan="2"><img src = "http://127.0.0.1:8080/atsec_logo.png"     height = "40" width = "150" /></td></td>
        
        
    </tr>
  <tr>  <td align="right"> End Date   <input type="date" name="endDate" value="<?= $endDate;?>"> </td> <td>&nbsp</td></tr>
    <tr>  <td align="center">  <button type='submit' >    Refresh  </button> 
    </form>   
        </td>  
          <script>
          n =  new Date();
          y = n.getFullYear();
          m = n.getMonth() +1;   //have to add one to get current month since array is zero-index based.
          d = n.getDate();
          
        </script>
    <!--  <td style="width:100px" >

      </td>
    -->
      <td>
        
        <script>
          AendDate=  y + '-' + m + '-' + d ;  //today's date 
          
          AstartDate= y-1+ '-' + m +'-' + d; //12 months earlier

        </script>
          <?php
          if($in_TopButtons==1)
            echo "<button  style=\"background-color: gray;\" type=\"button\" ";
          else
            echo "<button  style=\"background-color: silver;\" type=\"button\" ";
          ?>
           onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?in_TopButtons=1&startDate='+ AstartDate+ '&endDate='+ AendDate;"> Last 12 Months  
          
          </button> 
          

        </td>
        <td> 
        <script>
          BendDate=  y-1 + '-12-31' ;  //Dec 31st of the current year
          BstartDate= y-1 + '-01' +'-01'; //Jan 1st of last year 

        </script>

          <?php
          if($in_TopButtons==2)
            echo "<button  style=\"background-color: gray;\" type=\"button\" ";
          else
            echo "<button  style=\"background-color: silver;\" type=\"button\" ";
          ?>
           onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?in_TopButtons=2&startDate='+BstartDate+ '&endDate='+BendDate;"> Last Year  
          </button>  
        </td> 
      <td>
        
        <script>
          CendDate=  y + '-' + m + '-' + d ;  //today's date 
          CstartDate= y + '-01' +'-01'; //january 1st of the current year

        </script>
        <?php
          if($in_TopButtons==3)
            echo "<button  style=\"background-color: gray;\" type=\"button\" ";
          else
            echo "<button  style=\"background-color: silver;\" type=\"button\" ";
          ?>
           onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?in_TopButtons=3&startDate='+ CstartDate+ '&endDate='+ CendDate;"> This Year  
          </button> 
        
        </td>
        
        <td>
        <script>
          
          DendDate=  y + '-' +  m + '-' + d;  //today
          DstartDate=1995 + '-01-01'  ;  //birth of the CMVP program

        </script>
        <?php
          if($in_TopButtons==4)
            echo "<button  style=\"background-color: gray;\" type=\"button\" ";
          else
            echo "<button  style=\"background-color: silver;\" type=\"button\" ";
          ?>
            onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?in_TopButtons=4&startDate='+ DstartDate+ '&endDate=' + DendDate ;"> All Time  
          </button> 
        </td>
        <td style="width:75px"></td>
        <td>
        
        <?php
          if($in_TopButtons==5)
            echo "<button  style=\"background-color: gray;\" type=\"button\" ";
          else
            echo "<button  style=\"background-color: silver;\" type=\"button\" ";
          ?>
            onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?';"> Today  
          </button> 
        </td>
</tr>
   
 </table> <!-- date buttons -->

  
<hr style="border:solid 1px #000080" />


<table>
	<tr>	<td style="width:100px">
	</td>
	<td>
		<img src="getchart.php?<?php echo $chart1URL?>" border="0" usemap="#map1">

	</td>
	</tr>
</table>
<map name="map1">
<?php echo $imageMap?>

<?php if($in_TopButtons==5)
{ $startDate=$startDateOut;
  $endDate=$endDateOut; 
}?>

<area <?php echo $coor_non_atsec_msg2?> href='https://csrc.nist.gov/Projects/cryptographic-module-validation-program/modules-in-process/Modules-In-Process-List' target="_blank"
    title='CMVP MIP Website' />
<area <?php echo $coor_button1.  " href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtonsOut."&startDate=".$startDate."&endDate=".$endDate."'".
    " title='Status Pareto' />"; ?>
<area <?php echo $coor_button2. " href='http://127.0.0.1:8080/CMVP_Active_By_Module_Type_Pareto.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtonsOut."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Module Type Pareto' />"; ?>
<area <?php echo $coor_button3. " href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtonsOut."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Module In Process' />"?>
<area <?php echo $coor_button4. " href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtonsOut."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Historic Trend' />"?>
<area <?php echo $coor_button5. " href='http://127.0.0.1:8080/CMVP_MIP_forecast_stackedbar.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtonsOut."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Forecast (Linear Regression Model) ' />"?>
<area <?php echo $coor_zoomIn. " href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?zoom=".($zoom + .25)."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom In' />"?>
<area <?php echo $coor_zoomOut. " href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?zoom=".($zoom - .25)."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Out) ' />"?>
<area <?php echo $coor_zoomClear. " href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?zoom=1&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Clear) ' />"?>

</map>
</body>
</html>
