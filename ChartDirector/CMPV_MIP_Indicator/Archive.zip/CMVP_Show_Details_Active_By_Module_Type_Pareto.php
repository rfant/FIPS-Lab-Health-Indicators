<?php

define        ("red",0x00FF0000);
define      ("green",0x0000FF00);
define       ("blue",0x000000FF);
define ("light_blue",0x00eeeeff);
define  ("deep_blue",0x000000cc);
define      ("white",0x00FFFFFF);
define      ("black",0x00000000);
define      ("grey1",0x00dcdcdc);
define      ("grey2",0x00f6f6f6);

#=======================================================
//variables passed into this program from the calling program
$startDate=$_REQUEST["startDate"];
$endDate=$_REQUEST["endDate"];
$dataSetName = $_REQUEST["dataSetName"]; // "SL"
$xLabel= $_REQUEST["xLabel"]; //Module TYpe
$dataSet=$_REQUEST["dataSet"];  //atsec OR non-atsec


$OrderBy = isset($_REQUEST['OrderBy']) ? $_REQUEST['OrderBy'] : '3' ;
$Direction = isset($_REQUEST['Direction']) ? $_REQUEST['Direction'] : 'desc' ;

//toggle the direction each time.
if($Direction=='asc')
	$Direction='desc';
else
	$Direction='asc';

if($dataSet==0 || $dataSet==1 || $dataSet==2 || $dataSet==3)
	$where_clause = " and \"Clean_Lab_Name\" not like 'ATSEC' ";
else
	$where_clause= " and \"Clean_Lab_Name\" like 'ATSEC' ";


//echo "startDate=".$startDate." ";
//echo "endDate=".$endDate."<br></br> ";
//echo "dataSetname=".$dataSetName."<br></br>";
//echo "xLabel=".$xLabel."<br></br>";
//echo "OrderBy=".$OrderBy."<br></br>";
//echo "Direction=".$Direction."<br></br>";

#===========================================================================
#connect to postgreSQL database and get my detailed data
$appName = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$connStr = "host=postgres.aus.atsec  dbname=fantDatabase user=richard password==uwXg9Jo'5Ua connect_timeout=5 options='--application_name=$appName'";
$conn = pg_connect($connStr);

$sql_Str = "select to_number(\"Cert_Num\",'99999') as \"Cert_Num\",\"Module_Name\",\"Vendor_Name\",\"Clean_Lab_Name\" ,(TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY'))as validation_date,\"Status\",\"Standard\" ,\"Lab_Name\" ,\"Module_Type\",  \"SL\" from \"CMVP_Active_Table\" "
  . " where \"SL\" like '" . substr($dataSetName, -1) . "' and \"Module_Type\" like '%" . $xLabel . "' and
	(TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY')) between'".$startDate."' and  '".$endDate."' ".$where_clause." 
	  order by ".$OrderBy." ".$Direction." ; ";

//echo "Alpha SQL= " . $sql_Str ;


$result = pg_query($conn, $sql_Str);
$arr = pg_fetch_all($result);
if($arr==null)
	$num_mod=0;
else
	$num_mod=sizeof($arr);

//$num_mod=(null!==$arr) ? sizeof($arr) : '0';
echo $xLabel." ".$dataSetName." modules: " . $num_mod;
 
echo "<style> table {border-collapse: collapse; } td, th { padding: 10px; border: 2px solid #1c87c9;  } </style>";
echo "<style> table,   {border: 1px solid black;background-color:#f6f6f6;}</style>";

echo " <br></br>";
  
 echo "<table>"; // start a table tag in the HTML



echo "<tr> ";
echo "<th bgcolor=LightBlue >Row</th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=1&Direction=".$Direction." \" >Cert</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=2&Direction=".$Direction." \" >Module</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=3&Direction=".$Direction." \" >Vendor</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=4&Direction=".$Direction." \" >Lab</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=5&Direction=".$Direction." \" >Validation Date</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=6&Direction=".$Direction." \" >Status</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=7&Direction=".$Direction." \" >Standard</a></th>  ";


//NOTE: skip OrderBy=8 18  since I don't want to see the "Lab Name" since I've already shown the "clean Lab name"

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=9&Direction=".$Direction." \" >Module Type</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Module_Type_Pareto.php?dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=10&Direction=".$Direction." \" >SL</a></th>  ";


echo "</tr>";
$i=1;
    if ($num_mod>0) {
	    foreach($arr as $row){   //Creates a loop to loop through results
	      echo "<tr><td>".$i
	      				."</td><td> <a href=\"https://csrc.nist.gov/projects/cryptographic-module-validation-program/certificate/".$row['Cert_Num']." \"  target=\"_blank\"> "
	      				. $row['Cert_Num'] . "</a>  </td><td>  "  
	      				. $row['Module_Name'] . "  </td><td>  "
	                    . $row['Vendor_Name']. "  </td><td>  "
	                    . $row['Lab_Name'].  "  </td><td>  "
	                    . $row['validation_date']."  </td><td>  "
	                    . $row['Status']. "  </td><td>  "     
	                    . $row['Standard']." </td><td> "
	                    . $row['Module_Type']."  </td><td>  "
	                    . $row['SL']. "  </td></tr>";  
	      //$row['index'] the index here is a field name
	       $i++; 
	      } //for each
	  } //if num_mod

echo "</table>"; //Close the table in HTML

?>