<?php
require_once("../lib/phpchartdir.php");
define        ("red",0x00FF0000);
define      ("green",0x0000FF00);
define       ("blue",0x000000FF);
define ("light_blue",0x00eeeeff);
define  ("blue_gray",0x0098AFC7);
define ("light_blue2",0x0099ccff);
define  ("deep_blue",0x000000cc);
define      ("white",0x00FFFFFF);
define      ("black",0x00000000);
define      ("gray1",0x00dcdcdc);
define     ("yellow",0x00FFFF00);
define ("yellow_green",0x0052D017);
define ("green_yellow",0x00B1FB17);
define ("gray_cloud",0x00B6B6B4);
define ("battleship_gray",0x00848482);
define ("pumpkin_orange",0x00F87217);
define ("platinum",0x00E5E4E2);
define ("light_slate_gray",0x006D7B8D);
define ("marble_blue",0x00566D7E);
define ("dark_slate_blue",0x002B3856);
define ("transparent",0xFF000000);
define ("gray_goosea",0x00D1D0CE);

//===============================================

$self = isset($_SERVER['PHP_SELF']) ? $_SERVER['PHP_SELF'] : '#';
 $now = date("Y-m-d");
 
 $today1 = isset($_POST['today1']) ? $_POST['today1'] : '1995-01-01' ; //Ealiest CMVP validation date
 $today2 = isset($_POST['today2']) ? $_POST['today2'] : (new DateTime)->format('Y-m-d');
  
 $startDate = isset($_REQUEST["startDate"]) ? date('Y-m-d',strtotime($_REQUEST["startDate"])) : date('Y-m-d', strtotime($today1));
 $endDate = isset($_REQUEST["endDate"]) ? date('Y-m-d',strtotime($_REQUEST["endDate"])) : date('Y-m-d', strtotime($today2));

 $in_TopButtons=isset($_REQUEST["in_TopButtons"]) ? $_REQUEST["in_TopButtons"] : 4;

 $zoom=isset($_REQUEST["zoom"]) ?  $_REQUEST["zoom"] : 1;

 //echo "startDate=".$startDate." ";
 //echo "endDate=".$endDate;

//==================================================
//get sql query


#connect to postgreSQL database and get my chart data

$appName = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$connStr = "host=postgres.aus.atsec  dbname=fantDatabase user=richard password==uwXg9Jo'5Ua connect_timeout=5 options='--application_name=$appName'";


$conn = pg_connect($connStr);

//$CMVP_Table_Name="\"CMVP_MIP_Table\"";
$CMVP_Table_Name="\"CMVP_atsec_Only_MIP_Table\"";


//(case when fidays is not null then fidays else (select current_date)::date - \"Finalization_Start_Date\"::date end) as fidays

$sql_Str="
select \"TID\",\"Review_Pending_Start_Date\" as date,\"In_Review_Start_Date\",\"Coordination_Start_Date\",\"Finalization_Start_Date\" ,
EXTRACT (EPOCH from (\"Review_Pending_Start_Date\"::timestamp - '0001-01-01'::timestamp)) as rp, 
EXTRACT (EPOCH from (\"In_Review_Start_Date\"::timestamp - '0001-01-01'::timestamp)) as ir, 
EXTRACT (EPOCH from (\"Coordination_Start_Date\"::timestamp - '0001-01-01'::timestamp)) as co, 
EXTRACT (EPOCH from (\"Finalization_Start_Date\"::timestamp - '0001-01-01'::timestamp)) as fi, 
(case when rpdays is not null then rpdays else (select current_date)::date - \"Review_Pending_Start_Date\"::date end) as rpdays ,
(case when irdays is not null then irdays else (select current_date)::date - \"In_Review_Start_Date\"::date end) as irdays ,
(case when codays is not null then codays else (select current_date)::date - \"Coordination_Start_Date\"::date end) as codays, 
(case when \"Finalization_Start_Date\" is not null then 3 else 0 end) as fidays
from 
(select \"TID\",
\"Review_Pending_Start_Date\",\"In_Review_Start_Date\"::date - \"Review_Pending_Start_Date\"::date as rpDays,																	\"In_Review_Start_Date\",\"Coordination_Start_Date\"::date - \"In_Review_Start_Date\"::date as irDays,
\"Coordination_Start_Date\",\"Finalization_Start_Date\"::date-\"Coordination_Start_Date\"::date as coDays,
\"Finalization_Start_Date\", \"Finalization_Start_Date\"::date - \"Review_Pending_Start_Date\"::date as fidays,
\"Status2\" 
from \"CMVP_atsec_Only_MIP_Table\" where \"Review_Pending_Start_Date\" between '".$startDate."' and '".$endDate."' and (\"Status2\" like '%Promoted%' OR \"Status2\" like '%Reappear%' OR \"Status2\" is null) and ((\"In_Review_Start_Date\" is null AND \"Coordination_Start_Date\" is null AND \"Finalization_Start_Date\" is null) OR (\"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is null AND \"Finalization_Start_Date\" is null) OR (\"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is not null AND \"Finalization_Start_Date\" is null) OR (\"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is not null AND \"Finalization_Start_Date\" is not null) ) 
) as t1 order by \"Review_Pending_Start_Date\" 
";

/*$sql_Str_Trend_RP="
select \"TID\",
\"Review_Pending_Start_Date\" as date,\"In_Review_Start_Date\", 
EXTRACT (EPOCH from (\"Review_Pending_Start_Date\"::timestamp - '0001-01-01'::timestamp)) as rp, 
EXTRACT (EPOCH from (\"In_Review_Start_Date\"::timestamp - '0001-01-01'::timestamp)) as ir, 
(case when rpdays is not null then rpdays else (select current_date)::date - \"Review_Pending_Start_Date\"::date end) as rpdays , 
(case when irdays is not null then irdays else (select current_date)::date - \"In_Review_Start_Date\"::date end) as irdays 
from (select \"TID\", \"Review_Pending_Start_Date\",\"In_Review_Start_Date\"::date - \"Review_Pending_Start_Date\"::date as rpDays, \"In_Review_Start_Date\",\"Coordination_Start_Date\"::date - \"In_Review_Start_Date\"::date as irDays, \"Coordination_Start_Date\",\"Finalization_Start_Date\"::date-\"Coordination_Start_Date\"::date as coDays, \"Finalization_Start_Date\", \"Finalization_Start_Date\"::date - \"Review_Pending_Start_Date\"::date as fidays, \"Status2\" from \"CMVP_atsec_Only_MIP_Table\" 
	  where \"Review_Pending_Start_Date\" between  (select CURRENT_DATE) - INTERVAL '2 years' and (select current_date) + INTERVAL '1 years' and (\"Status2\" like '%Promoted%' OR \"Status2\" like '%Reappear%' OR \"Status2\" is null) 
	  and (		  \"In_Review_Start_Date\" is not null 		  ) 
	) as t1 order by \"Review_Pending_Start_Date\" 
	  
	  
	  
";*/

//echo "sql =".$sql_Str;

$result = pg_query($conn,$sql_Str);
$arr = pg_fetch_all($result);
if($arr==null)
	$num_mod=0;
else
	$num_mod=sizeof($arr);

foreach($arr as $row){
	$dataX0[]=$row['rp']; //review pending start date converted to seconds since 0001:01-01
}
foreach($arr as $row) {
	$dataY0[]=$row['rpdays'];  //number of days spent in rp
}
foreach($arr as $row) {
	$labels[]=$row['date']; //rp start date used for x-axis
}

foreach($arr as $row) {
	$TID[]=$row['TID'];
}


foreach($arr as $row){
	$dataX1[]=$row['ir']; //in review start date converted to number of seconds since 0001-01-01
}
foreach($arr as $row) {
	$dataY1[]=$row['irdays']; //number of days spent in ir
}

foreach($arr as $row){
	$dataX2[]=$row['co'];//coordination start date converted to number of seconds since 0001-01-01
}
foreach($arr as $row) {
	$dataY2[]=$row['codays']; //number of days spent in co
}

foreach($arr as $row){
	$dataX3[]=$row['fi']; //finalization start date converted to number of seconds since 0001-01-01
}
foreach($arr as $row) {
	$dataY3[]=$row['fidays']; //number of days spent in fi
}


//=======================================================================================
// draw the chart

# Create a XYChart object of size width x height pixels. Set the background to pale yellow (0xffffc0)
# with a black border (0x0)
//$zoom=1;

//echo "zoom=".$zoom;

$width=$zoom*800;
$height=$zoom*600;


//$c = new XYChart($width, $height, 0xffffc0, 0x000000);
//$c = new XYChart($width,$height, brushedSilverColor(), Transparent, 2);
$c = new XYChart($width, $height, light_blue, black, 1);
$c->setRoundedFrame();

# Set the plotarea at (50, 30) and of size 240 x 140 pixels. Use white (0xffffff) background.
$plotAreaObj = $c->setPlotArea(80,100, $width-200, $height-200);
$plotAreaObj->setBackground(0xffffff);

# Add a title to the chart using 15pt Times Bold Italic font. The text is white (ffffff) on a blue
# (0000cc) background, with glass effect.
$title = $c->addTitle("CMVP MIP Historic Trend  ", "timesbi.ttf", 15, 0xffffff);
$title->setBackground(0x0000cc, 0x000000, glassEffect(ReducedGlare));
//-------------------------------------------------------------------------------
//add some milestone bars here

//90B
$milestone90B=0;//90B
for($i=0;$i<sizeof($dataX0);$i++)
	if(getChartYMD($dataX0[$i])>='20201107')   //90B
		{$milestone90B=$i; break;	}
	else
		$milestone90B=0;
# Add a vertical red mark line for 90B at x = '2020-11-07'
if($milestone90B != 0)
	$c->xAxis->addMark($milestone90B, red, ""); //90B

//140-2 EOL
$milestone1402EOL=0;//1402EOL
for($i=0;$i<sizeof($dataX0);$i++)
	if(getChartYMD($dataX0[$i])>='20210921')   //140-2 EOL
		{$milestone1402EOL=$i; break;	}
	else
		$milestone1402EOL=0;
# Add a vertical red mark line for 1402EOL at x = '2021-09-21'
if($milestone1402EOL != 0)
	$c->xAxis->addMark($milestone1402EOL, red, ""); //90B

//140-3 
$milestone1403=0;//140-3
for($i=0;$i<sizeof($dataX0);$i++)
	if(getChartYMD($dataX0[$i])>='20200921')   //140-2 EOL
		{$milestone1403=$i; break;	}
	else
		$milestone1403=0;
# Add a vertical red mark line for 1403 at x = '2020-09-21'
if($milestone1403 != 0)
	$c->xAxis->addMark($milestone1403, red, ""); //90B


//---------------------------------------------------------------------
//Draw the right side buttons

$buttonX=$width-100; //700;
$buttonY=$height - 500; //100;

$ShowList = $c->addText(80-75, 550*$zoom, "Show All","arialbd.ttf", 8,black); //draw button
$ShowList->setSize(60, 25);
$ShowList->setBackground(light_blue,-1,2);
$ShowList->setAlignment (5);
$coor_ShowList = $ShowList->getImageCoor();

if($zoom>1){
$zoom_str="Zoom=". $zoom;
$zoom_rp = $c->addText($buttonX+5,$buttonY-100, $zoom_str ,"arialbd.ttf", 10,black); //draw button
$zoom_rp->setSize(20, 20);
}

$zoomIn = $c->addText($buttonX+10, $buttonY-60, "+","arialbd.ttf", 10); //draw button
$zoomIn->setSize(20, 20);
$zoomIn->setBackground(gray1,-1,2);
$zoomIn->setAlignment (5);
$coor_zoomIn = $zoomIn->getImageCoor();

$zoomOut = $c->addText($buttonX+40, $buttonY-60, "-","arialbd.ttf", 12); //draw button
$zoomOut->setBackground(gray1,-1,2);
$zoomOut->setSize(20, 20);
$zoomOut->setAlignment (5);
if($zoom <=1)
	$coor_zoomOut =0;
 else
	$coor_zoomOut = $zoomOut->getImageCoor();	//only make clickable button if zoom in already used.


$zoomClear = $c->addText($buttonX+70, $buttonY-60, "!","arialbd.ttf", 12); //draw button
$zoomClear->setSize(20, 20);
$zoomClear->setBackground(gray1,-1,2);
$zoomClear->setAlignment (5);
$coor_zoomClear = $zoomClear->getImageCoor();

//gray1 on
//battleship_gray off


$button1 = $c->addText($buttonX, $buttonY, "Status","arialbd.ttf", 10); //draw button
$button1->setSize(80, 30);
$button1->setBackground(gray1,-1,2);
$button1->setAlignment (5);
$coor_button1 = $button1->getImageCoor();

$button2 = $c->addText($buttonX, $buttonY+50, "Mod Type","arialbd.ttf", 10); //draw button
$button2->setSize(80, 30);
$button2->setBackground(gray1,-1,2);
$button2->setAlignment (5);
$coor_button2 = $button2->getImageCoor();


$button3 = $c->addText($buttonX, $buttonY+100, "MIP","arialbd.ttf", 10); //draw button
$button3->setSize(80, 30);
$button3->setBackground(gray1,-1,2);
$button3->setAlignment (5);
$coor_button3 = $button3->getImageCoor();



$button4 = $c->addText($buttonX, $buttonY+150, "Trend","arialbd.ttf", 10); //draw button
$button4->setSize(80, 30);
$button4->setBackground(battleship_gray,-1,-2);
$button4->setAlignment (5);
$coor_button4 = $button4->getImageCoor();

$button5 = $c->addText($buttonX, $buttonY+200, "Forecast","arialbd.ttf", 10); //draw button
$button5->setSize(80, 30);
$button5->setBackground(gray1,-1,2);
$button5->setAlignment (5);
$coor_button5 = $button5->getImageCoor();


//--------------------------------------------

# Add a legend box at (480, 20) using vertical layout and 12pt Arial font. Set background and border
# to transparent and key icon border to the same as the fill color.
$b = $c->addLegend(50,50, false, "arialbd.ttf", 12);
$b->setBackground(Transparent, Transparent);
$b->setKeyBorder(SameAsMainColor);


//---------------------------------------------------------------------------------------------
//put my data on the chart

# Add a stacked bar layer
$layer = $c->addBarLayer2(Stack);

# Add the three data sets to the bar layer
$layer->addDataSet($dataY0, light_blue2, "Review Pending");
$layer->addDataSet($dataY1,red, "In Review");
$layer->addDataSet($dataY2, green, "Coordination");
$layer->addDataSet($dataY3, black, "Finalization");


# Set the bar border to transparent
$layer->setBorderColor(Transparent);


//set the xLabels using the Review Pending Start Dates labels
$textBoxObj = $c->xAxis->setLabelStyle("arial.ttf", 10, black);
$textBoxObj->setFontAngle(90);
$c->xAxis->setLabels($labels); 

# Display 1 out of 5 date labels on the x-axis. Otherwise, it's too crowded to show all the dates.  Show minor ticks for remaining labels.
$c->xAxis->setLabelStep(5, 1);

//set up the x2Labels to use TID for the Show_Detail app
$textBoxObj=$c->xAxis2->setLabelStyle("arial.ttf",10,light_blue);  //set the color the same as the background. I don't really want the clutter of all the TIDs showing.
$c->xAxis2->setLabels($TID);
$c->xAxis2->setTickLength2(0,0);# Set the  major tick length to 0 pixels and minor tick length to 0 pixels (-ve means ticks inside  the plot area)


# Add a title to the y axis using dark grey (0x555555) 14pt Arial Bold font
$c->yAxis->setTitle("Days in State", "arialbd.ttf", 14, black);

//------------------------------------------------------------
// TREND: Least Square (linear regression) trend calculation

//I just want the slope and intercept values, so I'll let chartdirector calculate it for me.
//BUT, I don't actually want to show the trend line, so I'll make it transparent, which
// still allows me to get the slope/intercept so I can forecast completion dates.
/*
$result = pg_query($conn,$sql_Str_Trend_RP);
$arr = pg_fetch_all($result);
if($arr==null)
	$num_mod=0;
else
	$num_mod=sizeof($arr);


foreach($arr as $row) {
	$dataTY0[]=$row['rpdays'];  //number of days spent in rp
}



$trendLayer = $c->addTrendLayer($dataTY0, transparent);  //RP Exit: trend of number of days in RP
//$trendLayer = $c->addTrendLayer($dataTY0, black);  //RP Exit: trend of number of days in RP
$m_slope_rp=$trendLayer->getSlope();
$b_intercept_rp=$trendLayer->getIntercept();


*/


//----------------------------------------------
# Output the chart
//do the next steps twice where I output the chart. I need to get the position on the screen of the milestone lines but can only 
//calculate those after the chart is outputed.
# Create the image and save it in a temporary location
$chart1URL = $c->makeSession("chart1");

# Create an image map for the chart
$imageMap = $c->getHTMLImageMap("CMVP_Show_Details_MIP_Historic_Stackedbar.php", "{default}&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate, "title='{dataSetName}: {value|0} aDays '");
  

//-----------------------------------------------
# Get the x-coor for the text description of milestone dates. Add text  to the chart
//This step has to happen after the chart has already been outputed so that I can 
//calculate the new x coordinate of each milestone. I then add the text for the milestone, and then output the chart again.
// 90B
if($milestone90B != 0)
	{
	$coor_x = $c->getXCoor($milestone90B) ;
	$c->addText($coor_x, 110, "90B","arialbd.ttf", 12); 
	}	

// 140-2 EOL
if($milestone1402EOL != 0)
	{
	$coor_x = $c->getXCoor($milestone1402EOL) ;
	$c->addText($coor_x, 110, "140-2 EOL","arialbd.ttf", 12); 
	}	

// 140-3 
if($milestone1403 != 0)
	{
	$coor_x = $c->getXCoor($milestone1403) ;
	$c->addText($coor_x, 110, "140-3","arialbd.ttf", 12); 
	}	
# Output the chart a 2nd time with the new milestone labels
# Create the image and save it in a temporary location
$chart1URL = $c->makeSession("chart1");

# Create an image map for the chart
$imageMap = $c->getHTMLImageMap("CMVP_Show_Details_MIP_Historic_Stackedbar.php", "{default}&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate, "title='TID:{x2Label}:  \ {dataSetName} for {value|0} Days '");
  


?>  
<!----------------------------------------------------------------------------------------------------------------->
<body style="margin:5px 0px 0px 5px">
<!-- <div style="font-size:18pt; font-family:verdana; font-weight:bold">
    CMVP MIP Historic Trend (atsec only).
</div>
-->


<table> <!-- date buttons -->

	<form action="<?= $self; ?>" method="POST"> 
	
   	<tr>    <td align="right"> Start Date <input type="date" name="startDate" value="<?= $startDate;?>">   
   		<td rowspan="2"> <td colspan="2"><img src = "http://127.0.0.1:8080/atsec_logo.png"     height = "40" width = "150" /></td></td>
   			
   			
   	</tr>
	<tr>	<td align="right"> End Date   <input type="date" name="endDate" value="<?= $endDate;?>"> </td> <td>&nbsp</td></tr>
   	<tr> 	<td align="center">  <button type='submit' >    Refresh  </button> 
   	</form> 	
   			</td>  
   				<script>
					n =  new Date();
					y = n.getFullYear();
					m = n.getMonth() +1;   //have to add one to get current month since array is zero-index based.
					d = n.getDate();
					
				</script>
		<!--	<td style="width:100px" >

			</td>
		-->
			<td>
				
				<script>
					AendDate=  y + '-' + m + '-' + d ;  //today's date 
					
					AstartDate= y-1+ '-' + m +'-' + d; //12 months earlier
					Azoom= <?php echo $zoom ?>;

				</script>
   				<?php
   				if($in_TopButtons==1)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
   				 onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?in_TopButtons=1&startDate='+ AstartDate+ '&endDate='+ AendDate;"> Last 12 Months  
   				
   				</button> 
   				

   			</td>
   			<td> 
				<script>
					BendDate=  y-1 + '-12-31' ;  //Dec 31st of the current year
					
					BstartDate= y-1 + '-01' +'-01'; //Jan 1st of last year 
					Bzoom= <?php echo $zoom ?>;

				</script>

   			 	<?php
   				if($in_TopButtons==2)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>


   				 onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?in_TopButtons=2&startDate='+BstartDate+ '&endDate='+BendDate;"> Last Year  
   				</button>  
   			</td> 
			<td>
				
				<script>
					CendDate=  y + '-' + m + '-' + d ;  //today's date 
					
					CstartDate= y + '-01' +'-01'; //january 1st of the current year
					Czoom= <?php echo $zoom ?>;

				</script>
				<?php
   				if($in_TopButtons==3)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
   				
   				 onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?in_TopButtons=3&startDate='+ CstartDate+ '&endDate='+ CendDate;"> This Year  
   				</button> 
   			
   			</td>
   			
   			

   			<td>
				<script>
					
					DendDate=  y + '-' +  m + '-' + d;  //today
					 
					DstartDate=1995 + '-01-01'  ;  //birth of the CMVP program
					Dzoom= <?php echo $zoom ?>;

				</script>
				<?php
   				if($in_TopButtons==4)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
				
   				  onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?in_TopButtons=4&startDate='+ DstartDate+ '&endDate=' + DendDate ;"> All Time  
   				</button> 
   			</td>
</tr>
   
 </table> <!-- date buttons -->
   
<hr style="border:solid 1px #000080" />

<table>
	<tr>		<td style="width:100px">
	</td>
	<td>
		<img src="getchart.php?<?php echo $chart1URL?>" border="0" usemap="#map1">
	</td>
	</tr>
</table>
<map name="map1">
<?php echo $imageMap?>

<area <?php echo $coor_button1.  " href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?zoom=".$zoom."&in_TopButtons=". $in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
    " title='Status Pareto' />"; ?>
<area <?php echo $coor_button2. " href='http://127.0.0.1:8080/CMVP_Active_By_Module_Type_Pareto.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Module Type Pareto' />"; ?>
<area <?php echo $coor_button3. " href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?zoom=".$zoom."&in_TopButtons=".($in_TopButtons * -1)."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Pareto' />"?>
<area <?php echo $coor_button4. " href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Historic Trend' />"?>
<area <?php echo $coor_button5. " href='http://127.0.0.1:8080/CMVP_MIP_forecast_stackedbar.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Forecast (Linear Regression Model) ' />"?>
<area <?php echo $coor_zoomIn. " href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?zoom=".($zoom + .25)."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom In' />"?>
<area <?php echo $coor_zoomOut. " href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?zoom=".($zoom - .25)."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Out) ' />"?>
<area <?php echo $coor_zoomClear. " href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?zoom=1&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Clear) ' />"?>
<area <?php echo $coor_ShowList. " href='http://127.0.0.1:8080/CMVP_Show_Details_MIP_historic_stackedbar.php?startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Clear) ' />"?>   
</map>
</body>
</html> 


