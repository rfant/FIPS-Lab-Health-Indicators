<?php

define        ("red",0x00FF0000);
define      ("green",0x0000FF00);
define       ("blue",0x000000FF);
define ("light_blue",0x0099ccff);
define  ("deep_blue",0x000000cc);
define      ("white",0x00FFFFFF);
define      ("black",0x00000000);
define      ("grey1",0x00dcdcdc);
define      ("grey2",0x00f6f6f6);

#=======================================================
//variables passed into this program from the calling program
$startDate=$_REQUEST["startDate"];
$endDate=$_REQUEST["endDate"];
$dataSetName = $_REQUEST["dataSetName"];
$xLabel= $_REQUEST["xLabel"];
$dataSet=$_REQUEST["dataSet"];
$show_detail_value=isset($_REQUEST['show_detail_value']) ? $_REQUEST['show_detail_value'] : 0;
//$value= $_REQUEST["value"];

$OrderBy = isset($_REQUEST['OrderBy']) ? $_REQUEST['OrderBy'] : '3' ;
$Direction = isset($_REQUEST['Direction']) ? $_REQUEST['Direction'] : 'desc' ;

//toggle the direction each time.
if($Direction=='asc')
	$Direction='desc';
else
	$Direction='asc';

//echo "startDate=".$startDate." ";
//echo "endDate=".$endDate."<br></br> ";


#===========================================================================
#connect to postgreSQL database and get my detailed data
$appName = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$connStr = "host=postgres.aus.atsec  dbname=fantDatabase user=richard password==uwXg9Jo'5Ua connect_timeout=5 options='--application_name=$appName'";
$conn = pg_connect($connStr);

if($show_detail_value==0 ) {
$temp_str=" ";

}
else
{
  if($dataSet==1)
    $temp_str="  and (TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY')) between '".$startDate."' AND '".$endDate."'";
  else if($dataSet==2)  //became active as new cert
    $temp_str=" and length (\"Validation_Date\") = 10  and (TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY')) between '".$startDate."' AND '".$endDate."'";
  else if ($dataSet==3)
    $temp_str=" and (TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY'))  < '".$startDate."'  ";
  else if ($dataSet==4)  //already active but revalidatedbetween
    $temp_str=" and length (\"Validation_Date\") > 10  and (TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY')) between '".$startDate."' AND '".$endDate."'";
  else
    $temp_str=" ";
}

$temp_str_2 =" order by ".$OrderBy." ".$Direction." ; ";


$sql_Str = "select \"Cert_Num\"::int ,\"Module_Name\",\"Vendor_Name\",\"Clean_Lab_Name\" ,(TO_DATE(right(\"Validation_Date\",10),'MM/DD/YYYY'))as 
validation_date,\"Sunset_Date\",\"Status\",\"Standard\" ,\"Lab_Name\" ,\"Module_Type\",  \"SL\" from \"CMVP_Active_Table\" "
  . " where \"Status\" like '%' || right('" .$dataSetName . "',6) || '%'  and \"Clean_Lab_Name\" like '" . $xLabel. "%' 
 ";

$sql_Str=$sql_Str . $temp_str . $temp_str_2;
//echo "Alpha SQL= " . $sql_Str. "<br></br>" ;


$result = pg_query($conn, $sql_Str);
$arr = pg_fetch_all($result);

if($arr==null)
	$num_mod=0;
else
	$num_mod=sizeof($arr);


echo $xLabel." ".$dataSetName." modules: " . $num_mod;

//draw the "back" 
//echo " <button  style=\"background-color: silver;\" type=\"button\" ";
//echo "  onclick=\"window.location.href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?in_button=1&startDate='+ ".$startDate." +'&endDate='+ ".$endDate.";\"> BACK </button>"; 
//echo "  onclick=\"window.location.href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php;\"> BACK </button>"; 
         
  
 

          
          



echo "<style> table {border-collapse: collapse; } td, th { padding: 10px; border: 2px solid #1c87c9;  } </style>";
echo "<style> table,   {border: 1px solid black;background-color:#f6f6f6;}</style>";
//td td:nth-child(1) { text-align: center;}
echo " <br></br>";

      
    echo "<table>"; // start a table tag in the HTML



echo "<tr> ";

echo "<th bgcolor=LightBlue >Row</th>  ";
echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=1&Direction=".$Direction." \" >Cert</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=2&Direction=".$Direction." \" >Module</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=3&Direction=".$Direction." \" >Vendor</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=4&Direction=".$Direction." \" >Lab</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=5&Direction=".$Direction." \" >Validation Date</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=6&Direction=".$Direction." \" >Sunset Date</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=7&Direction=".$Direction." \" >Status</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=8&Direction=".$Direction." \" >Standard</a></th>  ";

//Skipping 9 since that just displays the lab name again

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=10&Direction=".$Direction." \" >Module Type</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_Active_By_Status_Pareto.php?show_detail_value=".$show_detail_value."&dataSet=".$dataSet."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=11&Direction=".$Direction." \" >SL</a></th>  ";


echo "</tr>";
//echo "</table>";
//echo "<table>";
$i=1;
    if ($num_mod>0) { 
    foreach($arr as $row){   //Creates a loop to loop through results
      echo "<tr><td>".$i
                      ."</td><td>  <a href=\"https://csrc.nist.gov/projects/cryptographic-module-validation-program/certificate/".$row['Cert_Num']." \"  target=\"_blank\"> "
                      . $row['Cert_Num'] . "</a>  </td><td>  "  
                      . $row['Module_Name'] . "  </td><td>  "
                      . $row['Vendor_Name']. "  </td><td>  "
                      . $row['Lab_Name'].  "  </td><td>  "
                      . $row['validation_date']."  </td><td>  "
                      . $row['Sunset_Date']."  </td><td>  "
                      . $row['Status']. "  </td><td>  "     
                      . $row['Standard']." </td><td> "
                      . $row['Module_Type']."  </td><td>  "
                      . $row['SL']. "  </td></tr>";
      $i++;  
      
      } //for each
  	} //if

echo "</table>"; //Close the table in HTML

?>
           