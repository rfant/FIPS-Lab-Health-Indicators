<!---
This page contains Javascript that generates the HTML for displaying the
sample charts on the right frame. To view the HTML, please right click on
an empty position on the right frame, and select "View Source" (for IE) or
"This Frame -> View Frame Source" (for FireFox).
--->
<html>
<head>
<script language="Javascript">
var charts = [
 //   ['', "CMVP Charts"],
    ['CMVP_Active_By_Status_Pareto.php', "", 0],
     
    ['CMVP_Active_By_Module_Type_Pareto.php', "", 0],
    ['CMVP_MIP_Pareto.php', "", 0],
  //   ['CMVP_MIP_Trend_Forecast.php', "CMVP MIP Trend Forecast", 0],
  //  ['CMVP_Active_By_Type_Pie.php', "CMVP Active By Type Pie ", 3],

    
    ['', ""]
    ];
/*function setChart(c)
{
    var doc = top.indexright.document;
    doc.open();
    doc.writeln('<body style="margin:5px 0px 0px 5px">');
    doc.writeln('<div style="font-size:18pt; font-family:verdana; font-weight:bold">');
    doc.writeln('    ' + charts[c][1]);
    doc.writeln('</div>');
    doc.writeln('<hr style="border:solid 1px #000080" />');
    doc.writeln('<div style="font-size:10pt; font-family:verdana; margin-bottom:1.5em">');
    doc.writeln('    <a href="viewsource.php?file=' + charts[c][0] + '">View Chart Source Code</a>');
    doc.writeln('</div>');
    if (charts[c][2] > 1)
    {
        for (var i = 0; i < charts[c][2]; ++i)
            doc.writeln('<img src="' + charts[c][0] + '?img=' + i + '">');
    }
    else
        doc.writeln('<img src="' + charts[c][0] + '">');
    doc.writeln('</body>');
    doc.close();
}*/
</script>
<style type="text/css">
p.demotitle {margin-top:1; margin-bottom:2; padding-left:1; font-family:verdana; font-weight:bold; font-size:9pt;}
p.demolink {margin-top:0; margin-bottom:0; padding-left:3; padding-top:2; padding-bottom:1; font-family:verdana; font-size:8pt;}
</style>
</head>
<body style="margin:0px">
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="font-family:verdana; font-size:8pt;">
<script language="Javascript">
for (var c in charts)
{
    if (charts[c][1] == "")
        //document.writeln('<tr><td><p class="demolink">&nbsp;</p></td></tr>');
    if (charts[c][0] == "")
       // document.writeln('<tr><td colspan="2" bgcolor="#9999FF"><p class="demotitle">' + charts[c][1] + '</p></td></tr>');
    else
    {
        // document.writeln('<tr><td colspan="2" bgcolor="#9999FF"><p class="demotitle">' + charts[c][1] + '</p></td></tr>');
        //document.write('<tr valign="top"><td><p class="demolink">&#8226;</p></td><td><p class="demolink">');
        if (charts[c][2] > 0)
          //  document.write('<a href="javascript:;" onclick="setChart(\'' + c + '\');">');
        else if (charts[c][2] == 0)
               document.write('<a href="' + charts[c][0] + '" target="indexright">');
        else
          //     document.write(charts[c][0]);
          // document.write(charts[c][1]);
          // document.writeln('</a></p></td></tr>');
    }
}
</script>
</table>


<table>
    <form action="<?= $self; ?>" method="POST"> 

    <tr>    <td> Start Date <input type="date" name="startDate" value="<?= $startDate;?>"> </td> </tr>
    <tr>    <td> End Date   <input type="date" name="endDate" value="<?= $endDate;?>"> </td> </tr>
    <tr>    <td>  <button type='submit' >    Refresh  </button> </td> </tr>
    </form>     
    </tr>  
                <script>
                    n =  new Date();
                    y = n.getFullYear();
                    m = n.getMonth() +1;   //have to add one to get current month since array is zero-index based.
                    d = n.getDate();
                    
                </script>
    <tr>
      <td>          
                <script>
                    AendDate=  y + '-' + m + '-' + d ;  //today's date 
                    
                    AstartDate= y-1+ '-' + m +'-' + d; //12 months earlier

                </script>
                <button style="background-color: silver;" type="button"
               
                <script language="Javascript">
                    document.write('<a href="' http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?startDate='+ AstartDate+ '&endDate='+ AendDate '" target="indexright">');
                </script>
                 <!--onclick="window.location.href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?startDate='+ AstartDate+ '&endDate='+ AendDate;"> Last 12 Months  -->
                </button> 
          </td>  
    </tr>
    <tr> 
        <td>
                <script>
                    BendDate=  y-1 + '-12-31' ;  //Dec 31st of the current year
                    
                    BstartDate= y-1 + '-01' +'-01'; //Jan 1st of last year 

                </script>

             <button style="background-color: silver;" type="button"
                 onclick="window.location.href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?startDate='+BstartDate+ '&endDate='+BendDate;"> Last Year  
                </button>  
        </td>
    </tr> 
    <tr>
        <td>       
                <script>
                    CendDate=  y + '-' + m + '-' + d ;  //today's date 
                    
                    CstartDate= y + '-01' +'-01'; //january 1st of the current year

                </script>
                <button style="background-color: silver;" type="button"
                 onclick="window.location.href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?startDate='+ CstartDate+ '&endDate='+ CendDate;"> This Year  
                </button> 
        </td>
    </tr>
            
            

    <tr>
        <td>
                <script>
                    
                    DendDate=  y + '-' +  m + '-' + d;  //today
                     
                    DstartDate=1995 + '-01-01'  ;  //birth of the CMVP program

                </script>
                <button style="background-color: silver;" type="button"
                  onclick="window.location.href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?startDate='+ DstartDate+ '&endDate=' + DendDate ;"> All Time  
                </button> 
        </td>        
    </tr>





    
 </table>


</body>
</html>
