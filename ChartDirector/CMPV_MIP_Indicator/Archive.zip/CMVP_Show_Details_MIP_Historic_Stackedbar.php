<?php

define        ("red",0x00FF0000);
define      ("green",0x0000FF00);
define       ("blue",0x000000FF);
define ("light_blue",0x00eeeeff);
define  ("deep_blue",0x000000cc);
define      ("white",0x00FFFFFF);
define      ("black",0x00000000);
define      ("grey1",0x00dcdcdc);
define      ("grey2",0x00f6f6f6);

#=======================================================
//variables passed into this program from the calling program
$startDate=$_REQUEST["startDate"];
$endDate=$_REQUEST["endDate"];

$today2 =  (new DateTime)->format('Y-m-d');
$todaysDate = date('Y-m-d', strtotime($today2));
 


$dataSetName = isset($_REQUEST["dataSetName"])? $_REQUEST["dataSetName"] : -1;
if($dataSetName=='RP Exit')
{
	echo "Nothing to see here. Click back arrow";
	return 1;
}


$xLabel= isset($_REQUEST["xLabel"])? $_REQUEST["xLabel"] : "ATSEC";
$TID_Index=isset($_REQUEST["x"]) ? $_REQUEST["x"] : -1;  // Negative One means to Show All TIDs

//$value= $_REQUEST["value"];

$OrderBy = isset($_REQUEST['OrderBy']) ? $_REQUEST['OrderBy'] : '1' ;
$Direction = isset($_REQUEST['Direction']) ? $_REQUEST['Direction'] : 'asc' ;

$in_TopButtons=isset($_REQUEST["in_TopButtons"]) ? $_REQUEST["in_TopButtons"] : 5;


//toggle the direction each time.
if($Direction=='asc')
	$Direction='desc';
else
	$Direction='asc';

//echo "startDate=".$startDate." ";
//echo "endDate=".$endDate."<br></br> ";

#===========================================================================
#connect to postgreSQL database and get my detailed data
$appName = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$connStr = "host=postgres.aus.atsec  dbname=fantDatabase user=richard password==uwXg9Jo'5Ua connect_timeout=5 options='--application_name=$appName'";
$conn = pg_connect($connStr);




	if($xLabel=='others')  
	{ //others and Today
		$lab_header='Lab (best guess)';  //used for the column header "LAB".
		//echo "others modules in ".$dataSetName;
		
		$sql_Str="select * from \"CMVP_MIP_Table\" where \"Coordination_Start_Date\" is not null AND \"Finalization_Start_Date\" is null and (\"Status2\" like '%Reappear%' OR \"Status2\" is NULL OR \"Status2\" like 'DUP%') order by ".$OrderBy." ".$Direction." ; "; 	
				
		
	} //Others and Today 
	else
	{  //must be atsec
		$lab_header='Lab (atsec only)';  //used for the column header "LAB".
		//echo "atsec modules in ".$dataSetName;
		$sql_Str="

		select \"TID\",\"Cert_Num\",\"Module_Name\",\"Vendor_Name\",'atsec' as \"Lab_Name\",\"Review_Pending_Start_Date\", (case
		when \"In_Review_Start_Date\" is null then (select current_date)::date - \"Review_Pending_Start_Date\"::date else \"In_Review_Start_Date\"::date - \"Review_Pending_Start_Date\"::date end )as rpDays, 

		
		
		\"In_Review_Start_Date\",(case when \"Coordination_Start_Date\" is null then (select current_date)::date - \"In_Review_Start_Date\"::date else \"Coordination_Start_Date\"::date - \"In_Review_Start_Date\"::date end) as irDays,
		
		 \"Coordination_Start_Date\", (case when \"Finalization_Start_Date\" is null then (select current_date)::date - \"Coordination_Start_Date\"::date else 
		 \"Finalization_Start_Date\"::date-\"Coordination_Start_Date\"::date end) as coDays,

		  (case when \"Finalization_Start_Date\" is null then 0 else 
		 (select current_date)::date-\"Finalization_Start_Date\"::date end) as fiDays,


		
		 \"Finalization_Start_Date\" ,

		 (case when \"Finalization_Start_Date\" is not null then \"Finalization_Start_Date\"::date - \"Review_Pending_Start_Date\"::date else  
		(select current_date)::date - \"Review_Pending_Start_Date\"::date 	end)	as totalDays,
		\"Standard\", \"Module_Type\",\"SL\" 

		from \"CMVP_atsec_Only_MIP_Table\" where \"Review_Pending_Start_Date\" between '".$startDate."' and '".$endDate."' and (\"Status2\" like '%Promoted%' OR \"Status2\" like '%Reappear%' OR \"Status2\" is null) and ((\"In_Review_Start_Date\" is null AND \"Coordination_Start_Date\" is null AND \"Finalization_Start_Date\" is null) OR (\"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is null AND \"Finalization_Start_Date\" is null) OR (\"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is not null AND \"Finalization_Start_Date\" is null) OR (\"In_Review_Start_Date\" is not null AND \"Coordination_Start_Date\" is not null AND \"Finalization_Start_Date\" is not null) ) 
		";
		
	}  //must be atsec




//do the query the first time to get the array of all the TID's
$sql_Str2=$sql_Str." order by \"Review_Pending_Start_Date\"";
//echo "<br></br>First SQL= " . $sql_Str."<br></br>" ;

$result = pg_query($conn, $sql_Str2);
$arr = pg_fetch_all($result);
$TID_Array=array();
$i=0;
foreach($arr as $row)
{	
	$TID_Array[]=$row['TID'];        //get the specific TID that I clicked on.
	
}

if($TID_Index==-1)
	$TID_String= "%";
else
	$TID_String=$TID_Array[$TID_Index];




//do the query a 2nd time time to get only the specific single TID that I want
$sql_Str=$sql_Str." and \"TID\" like '".$TID_String."'  order by ".$OrderBy." ".$Direction."  ";   
//echo "<br></br>2nd SQL= " . $sql_Str."<br></br>" ;

$result = pg_query($conn, $sql_Str);
$arr = pg_fetch_all($result);

echo "<style> table {border-collapse: collapse; } td, th { padding: 10px; border: 2px solid #1c87c9;  } </style>";
echo "<style> table,   {border: 1px solid black;background-color:#f6f6f6;}</style>";


      
$arr = pg_fetch_all($result);
$num_mod=(int) sizeof($arr); //-1 ;

//echo ": ".$num_mod;

foreach($arr as $row)
	$FI_SD_Array_Color[]=$row['fidays'];  //get this to set font color toll gray if this null. else color as black

foreach($arr as $row)
	$IR_SD_Array_Color[]=$row['irdays'];  //get this to set font color toll gray if this null. else color as black

foreach($arr as $row)
	$CO_SD_Array_Color[]=$row['codays'];  //get this to set font color toll gray if this null. else color as black


foreach($arr as $row)
	//$RP_DaysLeft_Array_Color[]=$row['rp_time_remaining'];  //get this to set font color toll red if this is greater than forecast.  else color as black

foreach($arr as $row)
//	$IR_DaysLeft_Array_Color[]=$row['ir_time_remaining'];  //get this to set font color toll red if this is greater than forecast.  else color as black

foreach($arr as $row)
//	$CO_DaysLeft_Array_Color[]=$row['co_time_remaining'];  //get this to set font color toll red if this is greater than forecast.  else color as black

$FI_Array=array();

foreach($arr as $row)
{	
	$Finalization_Start_Date_Array[]=$row['Finalization_Start_Date'];  //get this to color the cell yellow if this null. else color as green
	
}



$RP_SD_Emp_Str1=array();$RP_SD_Emp_Str2=array();
$IR_SD_Emp_Str1=array();$IR_SD_Emp_Str2=array();
$CO_SD_Emp_Str1=array();$CO_SD_Emp_Str2=array();
$FI_SD_Emp_Str1=array();$FI_SD_Emp_Str2=array();
$FI_background=array();

for($i=0;$i<(sizeof($FI_SD_Array_Color));$i++)
{//set up font colors

	//echo $i.": -".$Finalization_Start_Date_Array[$i]."-<br></br>";

	
	if($FI_SD_Array_Color[$i] == 0)
		$FI_background[$i]="\"#ffff00\"";  //yellow: still in progress
	else
		$FI_background[$i]="\"#90EE90\""; //green: finished


	//if remaining time is greater than what was forecasted, then mark text as red. else black
	//if($RP_DaysLeft_Array_Color[$i] > $forecast_Y_rp)
		//$RP_DaysLeft_Array_Color[$i]="\"#FF2400\""; //red
	//else
		$RP_DaysLeft_Array_Color[$i]="\"#0\""; //BLACK

	//if($IR_DaysLeft_Array_Color[$i] > $forecast_Y_ir)
		//$IR_DaysLeft_Array_Color[$i]="\"#FF2400\""; //red
	//else
		$IR_DaysLeft_Array_Color[$i]="\"#0\""; //BLACK

	//if($CO_DaysLeft_Array_Color[$i] > $forecast_Y_co)
		//$CO_DaysLeft_Array_Color[$i]="\"#FF2400\""; //red
	//else
		$CO_DaysLeft_Array_Color[$i]="\"#0\""; //BLACK

	//if the Start Date is forecasted, then mark as gray in italics. else black

	if($FI_SD_Array_Color[$i] == 0)
	{   $FI_SD_Emp_Str1[$i]="<em>"; 
		$FI_SD_Array_Color[$i]="\"#848482\""; //gray  
		$FI_SD_Emp_Str2[$i]="</em>"; 
		//$mycolor="\"#ffff00\"";  //yellow

	}
	else
	{	$FI_SD_Emp_Str1[$i]=""; 
		$FI_SD_Array_Color[$i]="\"#00000\""; //black
		$FI_SD_Emp_Str2[$i]=""; 
		//$mycolor="\"#90EE90\""; //green
	}	

	if($IR_SD_Array_Color[$i]==0)
	{   $IR_SD_Emp_Str1[$i]="<em>"; 
		$IR_SD_Array_Color[$i]="\"#848482\""; //gray
		$IR_SD_Emp_Str2[$i]="</em>"; 
	}
	else
	{	$IR_SD_Emp_Str1[$i]=""; 	
		$IR_SD_Array_Color[$i]="\"#00000\""; //black
		$IR_SD_Emp_Str2[$i]=""; 
	}		

	if($CO_SD_Array_Color[$i]==0)
	{   $CO_SD_Emp_Str1[$i]="<em>"; 
		$CO_SD_Array_Color[$i]="\"#848482\""; //gray
		$CO_SD_Emp_Str2[$i]="</em>"; 
	}
	else
	{	$CO_SD_Emp_Str1[$i]=""; 	
		$CO_SD_Array_Color[$i]="\"#00000\""; //black
		$CO_SD_Emp_Str2[$i]=""; 
	}	
}  //set up font colors




echo "<table>"; // start a table tag in the HTML
echo "<tr> ";


echo "<th bgcolor=LightBlue >Row</th>  ";
echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=1&Direction=".$Direction." \" >TID</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=2&Direction=".$Direction." \" >Cert_Num</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=3&Direction=".$Direction." \" >Module</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=4&Direction=".$Direction." \" >Vendor</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=5&Direction=".$Direction." \" >".$lab_header."</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=6&Direction=".$Direction." \" >RP Start Date</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=7&Direction=".$Direction." \" >Days in RP</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=8&Direction=".$Direction." \" >IR Start Date</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=9&Direction=".$Direction." \" >Days in IR</a></th>  ";


echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=10&Direction=".$Direction." \" >CO Start Date</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=11&Direction=".$Direction." \" >Days in CO </a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=13&Direction=".$Direction." \" >FI Start Date</a></th>  ";

/*echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=12&Direction=".$Direction." \" >Days in FI</a></th>  ";
*/
echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=14&Direction=".$Direction." \" >Total Days</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=16&Direction=".$Direction." \" >Module Type</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=17&Direction=".$Direction." \" >SL</a></th>  ";

echo "<th bgcolor=LightBlue ><a href=\"http://127.0.0.1:8080/CMVP_Show_Details_MIP_Historic_Stackedbar.php?x=".$TID_Index."&in_TopButtons=".$in_TopButtons."&xLabel=".$xLabel."&dataSetName=".$dataSetName."&startDate=".$startDate."&endDate=".$endDate."&OrderBy=15&Direction=".$Direction." \" >Standard</a></th>  ";


echo "</tr>";
$i=1;
    if ($num_mod>0) { 
    foreach($arr as $row){   //Creates a loop to loop through results
      	


      echo "<tr><td>".$i
                      ."</td><td> "
                      . $row['TID'] . "  </td>  "  
						."<td>  <a href=\"https://csrc.nist.gov/projects/cryptographic-module-validation-program/certificate/".$row['Cert_Num']." \"  target=\"_blank\"> "

                      . $row['Cert_Num'] . " </a>  </td><td>  "  
                      . $row['Module_Name'] . "  </td><td>  "
                      . $row['Vendor_Name']. "  </td><td>  "
                      . $row['Lab_Name'].  "  </td><td>  "
                      . $row['Review_Pending_Start_Date']." </td><td> "
                      . $row['rpdays']." </td><td> "
                      . $row['In_Review_Start_Date']."  </td><td>  "
                      . $row['irdays']." </td><td> "
                      . $row['Coordination_Start_Date']."  </td><td>  "
                      . $row['codays']." </td><td> "
                      . $row['Finalization_Start_Date']."  </td><td bgcolor=".$FI_background[$i-1].">  "
                     
                      . $row['totaldays']."  </td><td>  "
                      . $row['Module_Type']."  </td><td>  "
                      . $row['SL']."  </td><td>  "
                      . $row['Standard']. "  </td></tr>";
      $i++;  
      
      } //for each
  	} //if

echo "</table>"; //Close the table in HTML

?>

