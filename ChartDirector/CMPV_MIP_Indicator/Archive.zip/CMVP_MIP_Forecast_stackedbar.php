

<?php


//TBD:  Machine Learning Library Module
//require_once("../lib/phpchartdir.php");

/*require_once __DIR__ . '/vendor/autoload.php';

use Phpml\Classification\KNearestNeighbors;

$samples = [[1, 3], [1, 4], [2, 4], [3, 1], [4, 1], [4, 2]];
$labels = ['a', 'a', 'a', 'b', 'b', 'b'];

$classifier = new KNearestNeighbors();
$classifier->train($samples, $labels);

$classifier->predict([3, 2]);
// return 'b'
*/


//========================================
//include "./CMVP_MIP_Forecast_confidence_generator.php";
include './CMVP_MIP_Forecast_confidence_generator.php';


//==========================================


define        ("red",0x00FF0000);
define      ("green",0x0000FF00);
define       ("blue",0x000000FF);
define ("light_blue",0x00eeeeff);
define  ("blue_gray",0x0098AFC7);
define ("light_blue2",0x0099ccff);
define  ("deep_blue",0x000000cc);
define      ("white",0x00FFFFFF);
define      ("black",0x00000000);
define      ("gray1",0x00dcdcdc);
define     ("yellow",0x00FFFF00);
define ("yellow_green",0x0052D017);
define ("green_yellow",0x00B1FB17);
define ("gray_cloud",0x00B6B6B4);
define ("battleship_gray",0x00848482);
define ("pumpkin_orange",0x00F87217);
define ("platinum",0x00E5E4E2);
define ("light_slate_gray",0x006D7B8D);
define ("marble_blue",0x00566D7E);
define ("dark_slate_blue",0x002B3856);
define ("transparent",0xFF000000);

//===============================================
// Get all my input parameters that are passed into this app
//

 $self = isset($_SERVER['PHP_SELF']) ? $_SERVER['PHP_SELF'] : '#';
 $now = date("Y-m-d");
 
 $today1 = isset($_POST['today1']) ? $_POST['today1'] : '1995-01-01' ; //Ealiest CMVP validation date
 $today2 = isset($_POST['today2']) ? $_POST['today2'] : (new DateTime)->format('Y-m-d');
  
 $startDate = isset($_REQUEST["startDate"]) ? date('Y-m-d',strtotime($_REQUEST["startDate"])) : date('Y-m-d', strtotime($today1));
 $endDate = isset($_REQUEST["endDate"]) ? date('Y-m-d',strtotime($_REQUEST["endDate"])) : date('Y-m-d', strtotime($today2));

 $in_TopButtons=isset($_REQUEST["in_TopButtons"]) ? $_REQUEST["in_TopButtons"] : 4;

 $zoom=isset($_REQUEST["zoom"]) ? $_REQUEST["zoom"] : 1;

 $months_to_look_back=isset($_REQUEST["months_to_look_back"]) ? $_REQUEST["months_to_look_back"] : 24;

 //echo "startDate=".$startDate." ";
 //echo "endDate=".$endDate;

//===============================================================================
//get sql query


#connect to postgreSQL database and get my chart data

$appName = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$connStr = "host=postgres.aus.atsec  dbname=fantDatabase user=richard password==uwXg9Jo'5Ua connect_timeout=5 options='--application_name=$appName'";


$conn = pg_connect($connStr);

//=============================================
//first off, see if I need to update my confidence numbers.
//If I don't see today's date in the forecast_sql table, then I'll have to
//take 5 seconds to refresh it. Else, the numbers are current

$sql_Str_Confidence1="
select * from \"Model_Forecast_Confidence\" where \"Date\" = '".$today2."' order by \"Row_ID\" desc limit 1 ;
";

//echo "sql= ".$sql_Str_Confidence1;
$result = pg_query($conn,$sql_Str_Confidence1);
$arr = pg_fetch_all($result);

//calculate_confidence will be run once a day to refresh the numbers. Once today's numbers are in table, it will skip this.
if($arr==null)
		calculate_confidence();

	
//=======================================================================================
// draw the chart

# Create a XYChart object of size width x height pixels. Set the background to light blue # with a black border (0x0)

$width=$zoom*800;
$height=$zoom*600;
$c = new XYChart($width, $height, light_blue, black, 1);
$c->setRoundedFrame();

# Set the plotarea at (w-200,h-200) and of size w x h pixels. Use white (0xffffff) background.
$plotAreaObj = $c->setPlotArea(80,100, $width-200, $height-200);
$plotAreaObj->setBackground(0xffffff);

# Add a title to the chart using 15pt Times Bold Italic font. The text is white (ffffff) on a blue
# (0000cc) background, with glass effect.
$title = $c->addTitle("CMVP MIP Forecast ", "timesbi.ttf", 15, 0xffffff);
$title->setBackground(0x0000cc, 0x000000, glassEffect(ReducedGlare));


//---------------------------------------------------------------------
//Draw the buttons on the right side of the plot

$buttonX=$width-100; 
$buttonY=$height - 500; 



$ShowList = $c->addText(80-75, 550*$zoom, "Show All","arialbd.ttf", 8,black); //draw button
$ShowList->setSize(60, 25);
$ShowList->setBackground(light_blue,-1,2);
$ShowList->setAlignment (5);
$coor_ShowList = $ShowList->getImageCoor();



if($zoom>1){
$zoom_str="Zoom=". $zoom;
$zoom_rp = $c->addText($buttonX+5,$buttonY-100, $zoom_str ,"arialbd.ttf", 10,black); //draw button
$zoom_rp->setSize(20, 20);
}

$zoomIn = $c->addText($buttonX+10, $buttonY-60, "+","arialbd.ttf", 10,black); //draw button
$zoomIn->setSize(20, 20);
$zoomIn->setBackground(gray1,-1,2);
$zoomIn->setAlignment (5);
$coor_zoomIn = $zoomIn->getImageCoor();


$zoomOut = $c->addText($buttonX+40, $buttonY-60, "-","arialbd.ttf", 12,black); //draw button
$zoomOut->setBackground(gray1,-1,2);
$zoomOut->setSize(20, 20);
$zoomOut->setAlignment (5);
if($zoom <=1)
	$coor_zoomOut =0;  //only make this '-' button clickable if zoom >=1. No shrinking below "1".
 else
	$coor_zoomOut = $zoomOut->getImageCoor();	


$zoomClear = $c->addText($buttonX+70, $buttonY-60, "!","arialbd.ttf", 10,black); //draw clear button
$zoomClear->setSize(20, 20);
$zoomClear->setBackground(gray1,-1,2);
$zoomClear->setAlignment (5);
$coor_zoomClear = $zoomClear->getImageCoor();


//gray1 => Button is ON
//battleship_gray => Button is OFF

$button1 = $c->addText($buttonX, $buttonY, "Status","arialbd.ttf", 10,black); //draw button
$button1->setSize(80, 30);
$button1->setBackground(gray1,-1,2);
$button1->setAlignment (5);
$coor_button1 = $button1->getImageCoor();

$button2 = $c->addText($buttonX, $buttonY+50, "Mod Type","arialbd.ttf", 10,black); //draw button
$button2->setSize(80, 30);
$button2->setBackground(gray1,-1,2);
$button2->setAlignment (5);
$coor_button2 = $button2->getImageCoor();


$button3 = $c->addText($buttonX, $buttonY+100, "MIP","arialbd.ttf", 10,black); //draw button
$button3->setSize(80, 30);
$button3->setBackground(gray1,-1,2);
$button3->setAlignment (5);
$coor_button3 = $button3->getImageCoor();



$button4 = $c->addText($buttonX, $buttonY+150, "Trend","arialbd.ttf", 10,black); //draw button
$button4->setSize(80, 30);
$button4->setBackground(gray1,-1,2);
$button4->setAlignment (5);
$coor_button4 = $button4->getImageCoor();

$button5 = $c->addText($buttonX, $buttonY+200, "Forecast","arialbd.ttf", 10,black); //draw button
$button5->setSize(80, 30);
$button5->setBackground(battleship_gray,-1,-2);
$button5->setAlignment (5);
$coor_button5 = $button5->getImageCoor();


//--------------------------------------------
# Add a legend box at (480, 20) using vertical layout and 12pt Arial font. Set background and border
# to transparent and key icon border to the same as the fill color.
#
$b = $c->addLegend(50,50, false, "arialbd.ttf", 12);
$b->setBackground(Transparent, Transparent);
$b->setKeyBorder(SameAsMainColor);



//---------------------------------------------------------------------------------------------

//get my forecast information from sql table "Model_Forecast_Table" where I've stored all the model calculations
//already. The calculations are run once a day, and take several minutes. So, it's far better to do it once in the morning, and stored the
//information so I can retrieve it here later.
$sql_Str_Confidence2="
select * from \"Model_Forecast_Confidence\" order by \"Row_ID\" desc limit 1 ;
";

//echo "sql confidence=".$sql_Str_Confidence2;

$result = pg_query($conn,$sql_Str_Confidence2);
$arr = pg_fetch_all($result);
if($arr==null)
	{   echo "ERROR 372R:  SQL Query returned nothing<br></br>";
	$num_mod=0;
	}
else
{	$num_mod=sizeof($arr);
	//echo "Records Found=".$num_mod;
}
foreach($arr as $row) 
	$temp_rp_forecast[]=$row['RP_Value'];  //how much time is left before I exit "Review Pending"?

foreach($arr as $row) 
	$temp_ir_forecast[]=$row['IR_Value'];  //how much time is left before I exit "In Review"?

foreach($arr as $row) 
	$temp_co_forecast[]=$row['CO_Value'];  //how much time is left before I exit "Coordinationg"?

foreach($arr as $row) 
	$temp_rp_confidence[]=$row['RP_Confidence'];  //confidence level of this number based on scoring this value against historical data?

foreach($arr as $row) 
	$temp_ir_confidence[]=$row['IR_Confidence'];  //confidence level of this number based on scoring this value against historical data?

foreach($arr as $row) 
	$temp_co_confidence[]=$row['CO_Confidence'];  //confidence level of this number based on scoring this value against historical data?

foreach($arr as $row) 
	$temp_plus_minus_days[]=$row['plus_minus_days'];  //confidence level of this number based on scoring this value against historical data?

$forecast_Y_rp=$temp_rp_forecast[0];
$forecast_Y_ir=$temp_ir_forecast[0];
$forecast_Y_co=$temp_co_forecast[0];
$rp_conf_max=$temp_rp_confidence[0];
$ir_conf_max=$temp_ir_confidence[0];
$co_conf_max=$temp_co_confidence[0];
$plus_minus_days=$temp_plus_minus_days[0];



$trend_str="RP=". $forecast_Y_rp." (".$rp_conf_max."%)     IR=".$forecast_Y_ir." (".$ir_conf_max."%)     CO=".$forecast_Y_co." (".$co_conf_max."%)     +/- ".$plus_minus_days." ";
$trend_rp = $c->addText(80+50, 100-60, $trend_str ,"arialbd.ttf", 10*$zoom,red); //draw button
$trend_rp->setSize(40, 20);




//these are for  modules that have already entered "Reivew_Pending"
$sql_Str_Forecast="

(select \"TID\",\"Vendor_Name\", \"Review_Pending_Start_Date\" as StartDate, rp_time_remaining, ".$forecast_Y_ir." as ir_time_remaining, ".$forecast_Y_co." as co_time_remaining
 from (
	 select \"TID\",\"Vendor_Name\", \"Review_Pending_Start_Date\", 
	 abs((select (current_date)::date - (\"Review_Pending_Start_Date\" + INTERVAL '".$forecast_Y_rp." days')::date ))as rp_time_remaining 
	 from \"CMVP_atsec_Only_MIP_Table\" where \"Review_Pending_Start_Date\" between (select CURRENT_DATE) - INTERVAL '".$months_to_look_back." months' and (select current_date) and (\"Status2\" is null) and \"In_Review_Start_Date\" is null and \"Coordination_Start_Date\" is null and \"Finalization_Start_Date\" is null ) as subquery order by \"Review_Pending_Start_Date\" )
UNION
(select \"TID\", \"Vendor_Name\",\"In_Review_Start_Date\" as StartDate , 0 as rp_time_remaining, ir_time_remaining, ".$forecast_Y_co." as co_time_remaining 
from ( select \"TID\",\"Vendor_Name\", \"Review_Pending_Start_Date\",\"In_Review_Start_Date\", 
	  abs((select (current_date)::date - (\"In_Review_Start_Date\" + INTERVAL '".$forecast_Y_ir." days')::date ))as ir_time_remaining 
	  from \"CMVP_atsec_Only_MIP_Table\" where \"Review_Pending_Start_Date\" between (select CURRENT_DATE) - INTERVAL '".$months_to_look_back." months' and (select current_date) and (\"Status2\" is null) and \"In_Review_Start_Date\" is not null and \"Coordination_Start_Date\" is null and \"Finalization_Start_Date\" is null ) as subquery order by \"Review_Pending_Start_Date\" )
union
(
select \"TID\",\"Vendor_Name\", \"Coordination_Start_Date\" as StartDate, 0 as rp_time_remaining, 0 as ir_time_remaining, co_time_remaining
from ( 
	select \"TID\",\"Vendor_Name\",\"Review_Pending_Start_Date\",\"Coordination_Start_Date\", 
	abs(( select (current_date)::date - (\"Coordination_Start_Date\" + INTERVAL '".$forecast_Y_co." days')::date ))as co_time_remaining
 from \"CMVP_atsec_Only_MIP_Table\" where \"Review_Pending_Start_Date\" between (select CURRENT_DATE) - INTERVAL '".$months_to_look_back." months' and (select current_date) and (\"Status2\" is null) and \"Coordination_Start_Date\" is not null and \"Finalization_Start_Date\" is null
) as subquery  order by \"Review_Pending_Start_Date\"
)
order by StartDate, \"TID\"

";


//echo "sql =".$sql_Str_Forecast; 

$result = pg_query($conn,$sql_Str_Forecast);
$arr = pg_fetch_all($result);
if($arr==null)
	{   echo "ERROR 372d:  SQL Query returned nothing<br></br>";
	$num_mod=0;
	}
else
{	$num_mod=sizeof($arr);
	//echo "Records Found=".$num_mod;
}
foreach($arr as $row) 
	$dataY_rp_forecast[]=$row['rp_time_remaining'];  //how much time is left before I exit "Review Pending"?

foreach($arr as $row) 
	$dataY_ir_forecast[]=$row['ir_time_remaining'];  //how much time is left before I exit "In Review"?

foreach($arr as $row) 
	$dataY_co_forecast[]=$row['co_time_remaining'];  //how much time is left before I exit "Coordination"?

foreach($arr as $row) 
	$labels_forecast[]=$row['startdate']; // forecasted start dates used for x-axis

foreach($arr as $row) 
	$TID_forecast[]=$row['TID']; //TID for tool tip / hover information

foreach($arr as $row) 
	$Vendor_Name[]=$row['Vendor_Name']; //Get the Vendor Name for tool tip/ hover information


//------------------------------
// Let's draw the plot now!
//
$layer = $c->addBarLayer2(Stack);

// assign my data to the bars now.
$layer->addDataSet($dataY_rp_forecast,light_blue2, "Review_Pending");
$layer->addDataSet($dataY_ir_forecast,red, "In_Review");
$layer->addDataSet($dataY_co_forecast,green, "Coordination");



// set attributes of stacked bars
//Set the sub-bar gap to 0, so there is no gap between stacked bars with a group
$layer->setBarWidth(20 );
$layer->setBarGap(0.15, 1);
//$layer->setBorderColor(Transparent); // Set the bar border to transparent

//set the x-axis labels (xLabels) using the $TID labels
if($zoom==1)   //have to play with the TID axis font size since it gets truncated with zooming.
	$TID_fontsize=7;
if($zoom==1.5)
	$TID_fontsize=10;
if($zoom>=2)
	$TID_fontsize=11;
else
	$TID_fontsize=8;

$textBoxObj = $c->xAxis->setLabelStyle("arial.ttf", $TID_fontsize, black);
$c->xAxis->setLabels($TID_forecast);

//set up the y-axis. 
$textBoxObj = $c->yAxis->setLabelStyle("arial.ttf", 10, black);
$textBoxObj->setFontAngle(90);
$c->yAxis->setLabelFormat("{={value}*86400+" . chartTime(strtotime($today2)) . "|yyyy-mm-dd}");

# Set the  major tick length to 0 pixels and minor tick length to 0 pixels (-ve means ticks inside  the plot area)
$c->yAxis->setTickLength2(0,0);



//Set up the 2nd x-axis ( xAxis2) located at the top of the plot. set up the x2Labels to use TID for the mouse-over tool -tip
//set the color the same as the background so as to hide them. I don't really want the clutter of all the TIDs showing.
$textBoxObj=$c->xAxis2->setLabelStyle("arial.ttf",10,light_blue);  
$c->xAxis2->setLabels($Vendor_Name);
$c->xAxis2->setTickLength2(0,0);# Set the  major tick length to 0 pixels and minor tick length to 0 pixels 

# Swap the x and y axis to become a rotated chart
$c->swapXY();

//-------------------------------------------------------------------------------
//add some milestone bars here
//

$milestone1 =  strtotime("2021-07-04") - strtotime($today2);
$milestone1= number_format( ($milestone1 / (60*60*24)),0);
if($milestone1 > 0)
	$c->yAxis->addMark($milestone1, red, ""); # Add a vertical red mark line 

$milestone1 =  strtotime("2021-08-04") - strtotime($today2);
$milestone1= number_format( ($milestone1 / (60*60*24)),0);
if($milestone1 > 0)
	$c->yAxis->addMark($milestone1, red, ""); # Add a vertical red mark line 

$milestone1 =  strtotime("2021-12-21") - strtotime($today2);
$milestone1= number_format( ($milestone1 / (60*60*24)),0);
if($milestone1 > 0)
	$c->yAxis->addMark($milestone1, green, ""); # Add a vertical red mark line 


//------------------------------------------------------


# Create the image and save it in a temporary location
$chart1URL = $c->makeSession("chart1");

# Create an image map for the chart
$imageMap = $c->getHTMLImageMap("CMVP_Show_Details_MIP_Forecast_Stackedbar.php", "{default}&months_to_look_back=".$months_to_look_back."&forecast_Y_rp=".$forecast_Y_rp."&forecast_Y_ir=".$forecast_Y_ir."&forecast_Y_co=".$forecast_Y_co."&startDate=".$startDate."&endDate=".$endDate, 
	"title='tid={xLabel|0}:    Vendor:\"{x2Label|0}\"   {dataSetName|0} DaysLeft={values}  '");
  


?>  
<!----------------------------------------------------------------------------------------------------------------->
<body style="margin:5px 0px 0px 5px">


<table> <!-- date buttons -->

	<form action="<?= $self; ?>" method="POST"> 
	
   	<tr>    <td align="right"> Start Date <input type="date" name="startDate" value="<?= $startDate;?>">   
   		<td rowspan="2"> <td colspan="2"><img src = "http://127.0.0.1:8080/atsec_logo.png"     height = "40" width = "150" /></td></td>
   			
   			
   	</tr>
	<tr>	<td align="right"> End Date   <input type="date" name="endDate" value="<?= $endDate;?>"> </td> <td>&nbsp</td></tr>
   	<tr> 	<td align="center">  <button type='submit' >    Refresh  </button> 
   	</form> 	
   			</td>  
   				<script>
					n =  new Date();
					y = n.getFullYear();
					m = n.getMonth() +1;   //have to add one to get current month since array is zero-index based.
					d = n.getDate();
					
				</script>
		
			<td>
				
				<script>
					AendDate=  y + '-' + m + '-' + d ;  //today's date 
					
					AstartDate= y-1+ '-' + m +'-' + d; //12 months earlier

					Azoom= <?php echo $zoom ?>;

				</script>
   				<?php
   				if($in_TopButtons==1)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
   				 onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Forecast_stackedbar.php?in_TopButtons=1&startDate='+ AstartDate+ '&endDate='+ AendDate;"> Last 12 Months  
   				
   				</button> 
   			</td>
   			<td> 
				<script>
					BendDate=  y-1 + '-12-31' ;  //Dec 31st of the current year
					BstartDate= y-1 + '-01' +'-01'; //Jan 1st of last year 
					Bzoom= <?php echo $zoom ?>;
				</script>

   			 	<?php
   				if($in_TopButtons==2)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
   				 onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Forecast_stackedbar.php?in_TopButtons=2&startDate='+BstartDate+ '&endDate='+BendDate;"> Last Year  
   				</button>  
   			</td> 
			<td>
				<script>
					CendDate=  y + '-' + m + '-' + d ;  //today's date 
					CstartDate= y + '-01' +'-01'; //january 1st of the current year
					Czoom= <?php echo $zoom ?>;
				</script>
				<?php
   				if($in_TopButtons==3)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
   				 onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Forecast_stackedbar.php?in_TopButtons=3&startDate='+ CstartDate+ '&endDate='+ CendDate;"> This Year  
   				</button> 
   			</td>
   			<td>
				<script>
					DendDate=  y + '-' +  m + '-' + d;  //today
					DstartDate=1995 + '-01-01'  ;  //birth of the CMVP program
					Dzoom= <?php echo $zoom ?>;
				</script>
				<?php
   				if($in_TopButtons==4)
   					echo "<button  style=\"background-color: gray;\" type=\"button\" ";
   				else
   					echo "<button  style=\"background-color: silver;\" type=\"button\" ";
   				?>
   				  onclick="window.location.href='http://127.0.0.1:8080/CMVP_MIP_Forecast_stackedbar.php?in_TopButtons=4&startDate='+ DstartDate+ '&endDate=' + DendDate ;"> All Time  
   				</button> 
   			</td>
</tr>
   
 </table> <!-- date buttons -->
   
<hr style="border:solid 1px #000080" />

<table>
	<tr>		<td style="width:100px">
	</td>
	<td>
		<img src="getchart.php?<?php echo $chart1URL?>" border="0" usemap="#map1">
	</td>
	</tr>
</table>
<map name="map1">
<?php echo $imageMap?>

<area <?php echo $coor_button1.  " href='http://127.0.0.1:8080/CMVP_Active_By_Status_Pareto.php?zoom=".$zoom."&in_TopButtons=". $in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
    " title='Status Pareto' />"; ?>
<area <?php echo $coor_button2. " href='http://127.0.0.1:8080/CMVP_Active_By_Module_Type_Pareto.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Module Type Pareto' />"; ?>
<area <?php echo $coor_button3. " href='http://127.0.0.1:8080/CMVP_MIP_Pareto.php?zoom=".$zoom."&in_TopButtons=".($in_TopButtons * -1)."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Pareto' />"?>
<area <?php echo $coor_button4. " href='http://127.0.0.1:8080/CMVP_MIP_Historic_stackedbar.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Historic Trend' />"?>
<area <?php echo $coor_button5. " href='http://127.0.0.1:8080/CMVP_MIP_forecast_stackedbar.php?zoom=".$zoom."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='MIP Forecast (Linear Regression Model) ' />"?>
<area <?php echo $coor_zoomIn. " href='http://127.0.0.1:8080/CMVP_MIP_forecast_stackedbar.php?zoom=".($zoom + .25)."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom In' />"?>
<area <?php echo $coor_zoomOut. " href='http://127.0.0.1:8080/CMVP_MIP_forecast_stackedbar.php?zoom=".($zoom - .25)."&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Out) ' />"?>
<area <?php echo $coor_zoomClear. " href='http://127.0.0.1:8080/CMVP_MIP_forecast_stackedbar.php?zoom=1&in_TopButtons=".$in_TopButtons."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Clear) ' />"?>
<area <?php echo $coor_ShowList. " href='http://127.0.0.1:8080/CMVP_Show_Details_MIP_forecast_stackedbar.php?months_to_look_back=".$months_to_look_back."&forecast_Y_rp=".$forecast_Y_rp."&forecast_Y_ir=".$forecast_Y_ir."&forecast_Y_co=".$forecast_Y_co."&startDate=".$startDate."&endDate=".$endDate."'".
   " title='Zoom Clear) ' />"?>
</map>
</body>
</html> 


